// api/escalate.js
// Vercel Cron — רץ כל דקה ומסלים התראות שלא טופלו

import { createClient } from '@supabase/supabase-js';
import axios from 'axios';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

export default async function handler(req, res) {
  // אבטחה — רק Vercel Cron יכול לקרוא לזה
  if (req.headers.authorization !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).end();
  }

  const now = Date.now();

  // שלוף כל ההתראות הפעילות
  const { data: alerts } = await supabase
    .from('alerts')
    .select('*, devices(*)')
    .eq('status', 'active');

  for (const alert of alerts || []) {
    const device = alert.devices;
    const elapsed = now - new Date(alert.created_at).getTime();
    const callMs = (device.call_minutes || 2) * 60 * 1000;
    const madaMs = (device.mada_minutes || 5) * 60 * 1000;

    // שלב שיחה
    if (elapsed >= callMs && !alert.call_sent && device.enable_call) {
      await sendIVRCall(alert.device_id, device);
      await supabase
        .from('alerts')
        .update({ call_sent: true })
        .eq('id', alert.id);
    }

    // שלב מד"א
    if (elapsed >= madaMs && !alert.mada_sent && device.enable_mada) {
      await supabase
        .from('alerts')
        .update({ mada_sent: true, status: 'mada_called' })
        .eq('id', alert.id);
      console.log(`🚑 מד"א נקרא עבור ${alert.device_id}`);
      // TODO: חיוג ממשי למד"א
    }
  }

  res.json({ processed: alerts?.length || 0 });
}

async function sendIVRCall(deviceId, device) {
  const twiml =
    `<Response>` +
    `<Say language="he-IL">` +
    `שלום. זוהי התראת ZenSense. ` +
    `${device.elder_name} זקוק לעזרה. ` +
    `לאישור טיפול — לחצו 1. ` +
    `למגן דוד אדום — לחצו 2. ` +
    `לחזרה — לחצו 9.` +
    `</Say>` +
    `<Gather numDigits="1" action="${process.env.VERCEL_URL}/api/ivr?deviceId=${deviceId}" method="POST" timeout="10">` +
    `</Gather>` +
    `</Response>`;

  for (const phone of device.contacts) {
    try {
      await axios.post(
        `https://api.twilio.com/2010-04-01/Accounts/${process.env.TWILIO_SID}/Calls.json`,
        new URLSearchParams({
          To: phone,
          From: process.env.TWILIO_FROM,
          Twiml: twiml
        }),
        { auth: { username: process.env.TWILIO_SID, password: process.env.TWILIO_TOKEN } }
      );
    } catch (e) {
      console.error(`שגיאה בשיחה ל-${phone}:`, e.message);
    }
  }
}
