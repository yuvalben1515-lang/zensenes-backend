// api/alert.js
// POST /api/alert — התראת נפילה מהמכשיר

import { createClient } from '@supabase/supabase-js';
import axios from 'axios';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { deviceId, type } = req.body;
  // type: 'fall' או 'button'

  // שלוף הגדרות המכשיר מ-Supabase
  const { data: device, error } = await supabase
    .from('devices')
    .select('*')
    .eq('device_id', deviceId)
    .single();

  if (error || !device) {
    return res.status(404).json({ error: 'מכשיר לא נמצא' });
  }

  // שמור אירוע בדאטאבייס
  const { data: alert } = await supabase
    .from('alerts')
    .insert({
      device_id: deviceId,
      type,
      status: 'active',
      created_at: new Date().toISOString()
    })
    .select()
    .single();

  // שלח WhatsApp לכולם
  const contacts = device.contacts; // מערך מספרים
  const elderName = device.elder_name;
  const roomName = device.room_name;
  const isButton = type === 'button';

  const message =
    `${isButton ? '🆘' : '🚨'} *התראת ZenSense*\n\n` +
    `${isButton ? `${elderName} לחצו על כפתור החירום` : `זוהתה נפילה אצל ${elderName}`}\n` +
    `📍 מיקום: ${roomName}\n` +
    `⏰ שעה: ${new Date().toLocaleTimeString('he-IL')}\n\n` +
    `אנא בדקו מיד.\nשלח *טיפלתי* לאישור.`;

  for (const phone of contacts) {
    try {
      await axios.get(
        `https://api.callmebot.com/whatsapp.php?phone=${phone}&text=${encodeURIComponent(message)}&apikey=${process.env.CALLMEBOT_KEY}`
      );
    } catch (e) {
      console.error(`WhatsApp error for ${phone}:`, e.message);
    }
  }

  // תזמן הסלמה (Vercel Cron יטפל בזה)
  res.json({ success: true, alertId: alert.id });
}
